import { Bar } from "@ant-design/plots";
import { Spin } from "antd";
import { SocketRankServer } from "../../utils/socket";
import { useEffect, useState } from "react";
import projectList_1 from "https://danzonghao.oss-accelerate.aliyuncs.com/dcz-static/project_1.js";
// const projectList_1 = require("https://danzonghao.oss-accelerate.aliyuncs.com/dcz-static/project_1.js")

const DemoBar = () => {
  const [rank, setRank] = useState([{ project_id: "null", ticket: 0 }]);
  const [config, setCongfig] = useState({
    data: rank,
    xField: "ticket",
    yField: "project_id",
    seriesField: "project_id",
    legend: {
      position: "top-left",
    },
    height: 800,
  });
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    SocketRankServer.on("server_response", (res) => {
      // console.log('server_response', res);
      let _rank = [];
      let i = 0;
      for (i = 0; i < 10; i++) {
        // console.log(res.data[i][0])
        _rank.push({
          project_id: projectList_1[res.data[i][0]],
          ticket: res.data[i][1],
        });
      }
      // console.log(_rank)
      setLoading(false);
      setRank(_rank);
      setCongfig({
        data: _rank,
        height: 800,
        xField: "ticket",
        yField: "project_id",
        yAxis: {
          label: {
            formatter: (value) => {
              // 如果标签值的长度超过5个字符，则在末尾添加省略号
              if (String(value).length > 7) {
                return String(value).substring(0, 7) + '...';
              }
              return value;
            },
          },
        },
        seriesField: "project_id",
        legend: {
          position: "top-left",
        },
      });
    });
  }, [rank]);
  // console.log(config)

  return (
    <>
      <h1 style={{ fontSize: 20 }}>十大最受欢迎项目</h1>
      <Spin
        className="Spin"
        spinning={loading}
        size="large"
        style={{ height: 800 }}
      >
        <Bar {...config} />
      </Spin>
    </>
  );
};

export default DemoBar;
