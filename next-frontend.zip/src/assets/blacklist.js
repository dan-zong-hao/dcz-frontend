const blacklist = [
  {
    username: "",
    description: "",
  },
];
export default blacklist;
