import Socket from 'socket.io-client';
export const SocketRankServer = Socket('http://8.130.52.22:5000/update_rank');
